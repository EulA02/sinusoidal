import os
from datetime import datetime

####################
#  REPORT SIGNOFF  #
####################

def mainFunction(corner, report):
	passed = 0;
	failed = 0;
	unfinished = 0;
	flag_fatal = False;
	fatal = 0;
	string_failed = "";
	string_fatal = "";
	string_unfinished = "";
	files = os.listdir();
	x = len(files);
	i=0;
	for y in range(x):

		#Extra condition to find tests
		if corner in files[y] and 'test' in files[y] and '.log' in files[y]:
			current_file = open(files[y], "r");
			content = current_file.readlines();
			z = len(content);
			if '** TEST PASSED **\n' in content:
				passed = passed + 1;
				
			elif '** TEST FAILED **\n' in content:
				failed = failed + 1;
				for c in files[y]:
					string_failed += c
			else:
				for i in range(z):
					if 'UVM_FATAL @' in content[i]:
						fatal += 1;
						for d in files[y]:
							flag_fatal = True;
							string_fatal += d
						break;
				if flag_fatal != True:
					unfinished += 1;
					flag_fatal = False;
					 
								
					
			
			current_file.close();
	#report.write("#tests_passed ", passed, "#tests_failed ", failed, "#fatal_test ", fatal);
	print("PASSED TESTS", passed, "FAILED TESTS", failed, "FATAL TESTS", fatal);

# PLL FILES

# Var defined by User Input
def writeCorner(var):
	now = datetime.now()
	name = now.strftime('%Y-%m-%d.log');

	report = open(name, "w");
	report.write("%Y-%m-%d")

	if var == 0:
			corner = "naosei";
			mainFunction(corner, report);

	elif var == 1:
			# Button String;

			corner = "vsr";
			mainFunction(corner, report);

	elif var == 2:
			# Button String;
			corner = "tt";
			mainFunction(corner, report);

	elif var == 3:
			corner = ".log";
			mainFunction(corner, report);
	report.close();


writeCorner(1);
