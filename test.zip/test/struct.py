import os

####################
#  REPORT SIGNOFF  #
####################

class signoff:
	def __init__(self, nome, var2):
		self.nome = nome
	def print_value(self):
		print(self.nome)
	class pll:
		def __init__(self, tests_accepted):
			self.tests_accepted = tests_accepted
		def print_tests(self):
			print(self.tests_accepted)
		def show(self)
			return self.nome

	
inst=signoff("THD",



##tests_failed=0;
#	tests_accepted=0;
#	tests_failed_names='';


#var1=signoff()
##var1.tests_failed=23
#print(var1.tests_failed)
